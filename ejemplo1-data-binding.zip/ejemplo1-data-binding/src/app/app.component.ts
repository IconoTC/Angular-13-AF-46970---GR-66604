import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  nombre: string = 'Anabel';
  apellido: string = "Vegas";

  deshabilitado: boolean = true;

  texto: string = '';

  constructor(){
    // Crear un temporizador que cuando transcurran 5 segundos
    // habilite el boton
    setTimeout(() => {
      this.deshabilitado = false;
    }, 5000);
  }

  mostrar_saludo(): void{
    alert("Bienvenidos al curso de Angular");
  }
}
