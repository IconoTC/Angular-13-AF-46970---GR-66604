import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mio'
})
export class MioPipe implements PipeTransform {

  transform(dato: unknown, ...args: unknown[]): unknown {
    // Retornar el dato modificado segun los argumentos recibidos
    return dato + " modificado";
  }

}
/*
  Truncar el numero a 4 decimales
  0,1234567
  0,1234567 x 10000 = 01234,567
  Descartar la parte decimal
  01234 / 10000 = 0,1234
*/