import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  texto: string = "Bienvenidos al curso de Angular";

  persona: Object = {
    nombre: "Pepito", "apellido":"Perez", edad: 37,
    telefonos: {tel1: 915672389, tel2: 616123456}
  };

  numero: number = 765858866.56787654;
  porcentaje: number = 0.5355677;

  // Funciona de diferentes formas
  fecha: Date = new Date();
  //fecha: Date = new Date('8/25/2024');   // mes/dia/año
  //fecha: string = '8/25/2024';
}
