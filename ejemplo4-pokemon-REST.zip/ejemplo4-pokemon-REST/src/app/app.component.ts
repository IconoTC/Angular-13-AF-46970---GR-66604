import { Component } from '@angular/core';
import { PokemonService } from './services/pokemon.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  pokemons: any[] = [];
  anteriores: string = '';
  siguientes: string = '';
  nombre: string = '';
  pokemon: any;

  constructor(private pokemonService: PokemonService){
    
    // Esto no se puede hacer
    //this.pokemons = pokemonService.getAll();

    pokemonService.getAll().subscribe(datos => {
      console.log(datos);
      this.pokemons = datos.results;
      this.anteriores = datos.previous;
      this.siguientes = datos.next;
    });
  }

  buscar(): void{
    this.pokemonService.buscarPokemon(this.nombre).subscribe(item => {
      this.pokemon = item;
    });
  }

  atras(): void{
    this.pokemonService.emitirPeticion(this.anteriores).subscribe(datos => {
      //console.log(datos);
      this.pokemons = datos.results;
      this.anteriores = datos.previous;
      this.siguientes = datos.next;
    });
  }

  adelante(): void{
    this.pokemonService.emitirPeticion(this.siguientes).subscribe(datos => {
      //console.log(datos);
      this.pokemons = datos.results;
      this.anteriores = datos.previous;
      this.siguientes = datos.next;
    });
  }
}
