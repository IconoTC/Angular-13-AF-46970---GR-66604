import { Component } from '@angular/core';
import { AgendaService } from './services/agenda.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { nextTick } from 'process';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  amigos: any[] = [];
  id: string = '';
  contacto: any;
  mostrar: boolean = false;

  amigoForm = new FormGroup({
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])
  });

  constructor(private agendaService: AgendaService){
    agendaService.getAll().subscribe(datos => {
      // limpiar la lista de amigos
      this.amigos = [];

      datos.forEach(item => {
        this.amigos.push(item.payload.doc.data())
      });
    });
  }

  modificar(): void{
    this.mostrar = true;
    this.amigoForm.setValue(this.contacto);
  }

  guardarCambios(): void{
    this.agendaService.modificar(this.id, this.amigoForm.value)
      .then( () => {
        setTimeout( () => {
          this.mostrar = false;
          this.contacto = null;
          this.id = '';
          this.amigoForm.reset();
        }, 500 )
      })
      .catch( error => {
        console.log(error);
      })
  }

  borrar(): void{
    this.agendaService.eliminar(this.id)
      .then( () => {
        this.id = '';
        this.contacto = null;
        alert("Contacto eliminado");
      })
      .catch( error => {
        console.log(error);
      })
  }

  buscar(): void{
    // el id ahora debe ser un string, cambiarlo en la propiedad
    this.agendaService.buscarAmigo(this.id).subscribe(item => {
      this.contacto = item.payload.data();
    })
  }

  alta(){
    this.agendaService.nuevoAmigo(this.amigoForm.value)
      .then( () => {
        alert("Contacto creado");
        this.amigoForm.reset();
      })
      .catch( error => {
        console.log(error);
      })
  }
}
