export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyDeJ55CjLugFuxS6XBNjTHEXOGhFNeS3gw",
    authDomain: "angular-indra-anabel-29-nov.firebaseapp.com",
    projectId: "angular-indra-anabel-29-nov",
    storageBucket: "angular-indra-anabel-29-nov.firebasestorage.app",
    messagingSenderId: "1027574280218",
    appId: "1:1027574280218:web:2b6e07ac3a7d555fc261a3"
  }
};
