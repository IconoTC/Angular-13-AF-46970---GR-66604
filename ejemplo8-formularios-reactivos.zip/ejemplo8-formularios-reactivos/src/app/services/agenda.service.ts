import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AgendaService {

  private amigos: any[] = [
    {id:1, nombre: 'Juan', telefono: 616111111},
    {id:2, nombre: 'Maria', telefono: 616222222}
  ];

  constructor() { }

  getAll(): any[]{
    return this.amigos;
  }

  buscarAmigo(id: number): any{
    return this.amigos.find(item => item.id == id);
  }

  nuevoAmigo(nuevo: any): void{
    this.amigos.push(nuevo);
  }

  eliminar(id: number): void{
    let indice = this.amigos.findIndex(item => item.id == id);
    this.amigos.splice(indice, 1);
  }

  modificar(amigo: any): void{
    this.amigos.forEach(item => {
      if (item.id == amigo.id){
        item.nombre = amigo.nombre;
        item.telefono = amigo.telefono;
      }
    });
  }
}
