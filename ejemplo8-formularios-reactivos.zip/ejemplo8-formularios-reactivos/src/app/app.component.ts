import { Component } from '@angular/core';
import { AgendaService } from './services/agenda.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  amigos: any[] = [];
  id: number = 0;
  contacto: any;
  mostrar: boolean = false;

  amigoForm = new FormGroup({
    id: new FormControl(0, [Validators.required, Validators.min(1)]),
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])
  });

  constructor(private agendaService: AgendaService){
    this.amigos = agendaService.getAll();
  }

  modificar(): void{
    this.mostrar = true;
    this.amigoForm.setValue(this.contacto);
  }

  guardarCambios(): void{
    this.agendaService.modificar(this.amigoForm.value);
    this.mostrar = false;
    this.contacto = null;
    this.id = 0;
    this.amigoForm.reset();
  }

  borrar(): void{
    this.agendaService.eliminar(this.id);
    this.id = 0;
    this.contacto = null;
  }

  buscar(): void{
    this.contacto = this.agendaService.buscarAmigo(this.id);
  }

  alta(){
    console.log(this.amigoForm.value);
    this.agendaService.nuevoAmigo(this.amigoForm.value);
    // limpiar el formulario
    this.amigoForm.reset();
  }
}
