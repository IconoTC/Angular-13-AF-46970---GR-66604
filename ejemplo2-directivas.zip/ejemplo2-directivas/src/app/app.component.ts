import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  alumnos: any[] = [
    {valoracion: 'media', repetidor: false, nombre: 'Juan', apellido: 'Lopez', nota: 7.5},
    {valoracion: 'alta', repetidor: false, nombre: 'Luis', apellido: 'Sanchez', nota: 8.3},
    {valoracion: 'baja', repetidor: false, nombre: 'Maria', apellido: 'Arias', nota: 2.4},
    {valoracion: 'bajaaaaaaa', repetidor: true, nombre: 'Pedro', apellido: 'Rodriguez', nota: 4.1},
    {valoracion: 'alta', repetidor: false, nombre: 'Laura', apellido: 'Cela', nota: 9.7},
    {valoracion: 'media', repetidor: true, nombre: 'Rocio', apellido: 'Gonzalez', nota: 6.8}
  ];
}
