import { ContarCliksDirective } from './contar-cliks.directive';

describe('ContarCliksDirective', () => {
  it('should create an instance', () => {
    const directive = new ContarCliksDirective();
    expect(directive).toBeTruthy();
  });
});
